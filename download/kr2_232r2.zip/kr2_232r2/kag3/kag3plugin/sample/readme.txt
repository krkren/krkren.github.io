This is something that might be helpful as a reference when creating KAG plugins.
Since it is intended merely as a reference during creation, it might not be practical,
or the design might be rough.

clock.ks is a sample that displays a clock.
clocktest.ks is the test scenario for it.
I think clock.ks will be useful as a reference when writing plugins that
keep a layer displaying some information on the screen at all times.

systembutton.ks is a sample that displays "Save" and "Load" buttons
on the screen.
systembuttontest.ks is the test scenario for it.
I think this serves as a sample for when you want to add buttons like
Save or Load to the edge of the message frame.

rclick_tjs.ks is a sample for writing right-click routines in TJS2.
rclick_tjs_test.ks is the test scenario for it.
It is more efficient to write complex configuration screens and the like in TJS2.
In this sample, you can add comments to save data, or configure
"Data Protection" to prevent accidentally overwriting save data.