This is a super simple audio player.

Please launch it by specifying this 'player' folder when starting Kirikiri,
or by dropping this folder onto the Kirikiri executable.

To exit, press Shift + F4. Please be careful to make the player the active
window before pressing it, otherwise an unrelated window might close.
Alternatively, you can right-click Kirikiri on the taskbar and select
"Close" to exit.

Playable formats are uncompressed or Microsoft ADPCM compressed wave (*.wav),
TCWF (*.tcw), and Ogg Vorbis (*.ogg).

When launched, a small, long horizontal window will be displayed. Drop the
file you want to listen to from Explorer or similar onto this window.
Playback will start immediately upon dropping. You can pause playback by
right-clicking.

Pressing the V key allows you to change the display type of the spectrum analyzer.

Playback will loop. You can check the loop status.


You can issue several commands via the console. Here are some simple examples:


Do not loop
a.buf.looping = false

Stop playback
a.buf.stop()