======================================================================
                        Transition Library
======================================================================


■ What is the Transition Library --------------------------------------

 This is a collection of rule images for use with Kirikiri's Universal Transitions.

 You can use them as rule images for the Universal Transition system in
 Kirikiri.

 The included rule images are as follows:


Rub (Left to Right)                                [rub_lr.png]
Horizontal blind that is slightly different...     [blind_horz_alt_lr.png]
Diamond (Left to Right)                            [diamond_lr.png]
Diamond (Top-Left to Bottom-Right)                 [diamond_tl_br.png]
Slightly fine horizontal blind (Top to Bottom)     [blind_horz_mid_tb.png]
Slightly fine horz. blind (Short trail, Top-Bot)   [blind_horz_mid_short_tb.png]
Slightly fine vertical blind (Center to L/R)       [blind_vert_mid_center_out.png]
Slightly fine vertical blind (Left to Right)       [blind_vert_mid_lr.png]
Slightly fine vert. blind (Short trail, L-R)       [blind_vert_mid_short_lr.png]
Checker                                            [checker.png]
Mosaic                                             [mosaic.png]
Random                                             [random.png]
Top to Bottom                                      [wipe_tb.png]
Bottom to Top                                      [wipe_bt.png]
Circle (Inside to Outside)                         [circle_out.png]
Circle (Outside to Inside)                         [circle_in.png]
Right to Left                                      [wipe_rl.png]
Right Spiral                                       [spiral_right.png]
Left to Right                                      [wipe_lr.png]
Bottom-Left to Top-Right                           [wipe_bl_tr.png]
Left Rotate (Counter-Clockwise)                    [spiral_left.png]
Continuous Left Rotate                             [spiral_left_continuous.png]
Radial (Clockwise)                                 [radial_clockwise.png]
Diagonal Checker                                   [checker_diag.png]
Diagonal Blind (Top-Left to Bottom-Right)          [blind_diag_tl_br.png]
Horizontal Blind (Top to Bottom)                   [blind_horz_tb.png]
Horizontal Blind                                   [blind_horz.png]
Wave                                               [wave.png]
Explosion                                          [explode.png]
Fine Diamond (Left to Right)                       [diamond_fine_lr.png]
Fine Diamond (Top-Left to Bottom-Right)            [diamond_fine_tl_br.png]
Fine Horizontal Blind (Top to Bottom)              [blind_horz_fine_tb.png]
Fine Horz. Blind (Short trail, Top-Bottom)         [blind_horz_fine_short_tb.png]
Fine Vertical Blind (Left to Right)                [blind_vert_fine_lr.png]
Fine Vertical Blind (Short trail, Left-Right)      [blind_vert_fine_short_lr.png]
Vertical Blind (Left to Right)                     [blind_vert_lr.png]
Vertical Blind                                     [blind_vert.png]
Worm-eaten (Dissolve)                              [dissolve_worms.png]


■ Tips for Use --------------------------------------------------------

 You can also use these images by inverting colors or flipping them
 horizontally/vertically.
 For most rule images, vague=1 is OK.
 Rule images with fine patterns may display more cleanly if set to around
 vague=20.


■ Caution --------------------------------------------------------------

 Double-byte characters (so-called full-width characters) are used in the
 filenames of the rule images.
 This should not theoretically be a problem, but if possible, please rename
 them to single-byte only filenames when actually using them.


■ Other ------------------------------------------------------------

 No copyright is claimed for the rule images.
 This data is free software. Please refer to the Kirikiri SDK Help for
 detailed information.

 Contact: W.Dee <dee@kikyou.info>
 http://kikyou.info/tvp/

----------------------------------------------------------------------
[EOF]